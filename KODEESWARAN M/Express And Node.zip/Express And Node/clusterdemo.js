var cluster=require('cluster')
var http=require('http')
var cpus=require('os').cpus.length;
if(cluster.isMaster){
    masterprocess()
}
else{
    ChildProcess()
}
function masterprocess(){
    console.log(`master ${process.pid} is running`);

    for(let i=0;i<cpus;i++){
        console.log(`forking process number ${i}`);
        cluster.fork();
    }
    process.exit();
}

function ChildProcess(){
    console.log(`child ${process.pid} started and competed`);
    process.exit();
}

