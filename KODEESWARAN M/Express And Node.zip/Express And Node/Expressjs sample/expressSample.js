var express=require('express');
var server=express();
server.get("/",(request,response)=>{
    response.send("<h1>expressjs app</h1>");
})

server.get("/home",(request,response)=>{
    response.send("<h1>expressjs application</h1>");
})

server.listen(5000,()=>{
    console.log("express server is waiting for client connection");
}) 